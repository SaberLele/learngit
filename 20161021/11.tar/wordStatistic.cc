 ///
 /// @file    wordStatistic.cc
 /// @author  lemon(ccx19930930@gmail.com)
 /// @date    2016-10-21 11:49:30
 ///
 
#include <iostream>
#include<map>
#include <fstream>
#include <vector>
#include <sstream>
#include <string>
using std::cout;
using std::endl;
using std::cin;
using std::string;
using std::vector;
using std::ofstream;
using std::ifstream;
using std::istringstream;
using std::ostringstream;
using std::map;
class Word_Node{
public:
	Word_Node(const string & s,int num=1);
	void addNum();
	const string & getString()const;
	int getNum()const;
private:
	const string _word;
	int _num;
};
Word_Node::Word_Node(const string &s,int num)
:_word(s)
,_num(num)
{
//	cout<<"Word_Node"<<endl;	
}
void Word_Node::addNum()
{
	_num++;
}
const string & Word_Node::getString()const
{
	return _word;
}
int Word_Node::getNum()const 
{
	return _num;
}
class WordStatistic{
public:
	void readfile(const string & filename);
	void writefile(const string & filename)const;

private:
	vector<Word_Node> _words;
};
void WordStatistic::readfile(const string & filename)
{
	ifstream ifs(filename);
	if(!ifs.good())
	{
		cout<<"ifstream open erro"<<endl;
		return ;
	}
	string line;
	istringstream iss;
	string word;
	vector<Word_Node>::iterator iter;
	while(getline(ifs,line))
	{
		iss.clear();
		iss.str(line);
		while(iss>>word)
		{
			for(iter=_words.begin();iter!=_words.end();iter++)
			{
				if((*iter).getString()==word)
				{
					(*iter).addNum();
					break;
				}
			}
			if(iter==_words.end())
			{
				_words.push_back(Word_Node(word));
			}
		}
	}
	ifs.close();
}
void WordStatistic::writefile(const string & filename)const
{
	ofstream ofs(filename);
	if(!ofs.good())
	{
		cout<<"ofstream open error"<<endl;
		return ;
	}
	for(auto & elem : _words)
	{
		ostringstream oss;
		oss<<elem.getString()<<"  "<<elem.getNum();
		ofs<<oss.str()<<endl;
	}
	ofs.close();
}
class WordStatistic2 {
public:
	void read_file(const string & filename);
	void write_file(const string & filename)const;
private:
	map<string,int>_words;
};
void WordStatistic2::read_file(const string & filename)
{
	ifstream ifs(filename);
	if(!ifs.good())
	{
		cout<<"ifstream open error"<<endl;
		return ;
	}
	string line;
	string word;
	istringstream iss;
	while(getline(ifs,line))
	{
		iss.clear();
		iss.str(line);
		while(iss>>word)
		{
			_words[word]++;
		}
	}
	ifs.close();
}
void WordStatistic2::write_file(const string & filename)const
{
	ofstream ofs(filename);
	if(!ofs.good())
	{
		cout<<"ofstream open error"<<endl;
		return ;
	}
	for(auto & elem : _words)
	{
		ostringstream oss;
		oss<<elem.first<<" "<<elem.second;
		ofs<<oss.str()<<endl;
	}
	ofs.close();
}
int main()
{
// 方法1：
#if 0
	WordStatistic wordSta;
	string readfile,writefile;
	cout<<"input the path of readfile"<<endl;
	cin>>readfile;
	cout<<"input the path of writefile"<<endl;
	cin>>writefile;
	wordSta.readfile(readfile);
	wordSta.writefile(writefile);
	return 0;
#endif
//  方法二：用map
#if 1	
	WordStatistic2 wordSta2;
	string readfile2,writefile2;
	cout<<"input the path of readfile"<<endl;
	cin>>readfile2;
	cout<<"input the path of writefile"<<endl;
	cin>>writefile2;
	wordSta2.read_file(readfile2);
	wordSta2.write_file(writefile2);
	return 0;
#endif
}
